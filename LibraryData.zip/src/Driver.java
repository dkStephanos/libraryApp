/**
 * ---------------------------------------------------------------------------
 * File name: Driver.java
 * Project name: Books
 * ---------------------------------------------------------------------------
 * Creator's name and email: Koi Stephanos, stephanos@goldmail.etsu.edu
 * Course:  CSCI 1260
 * Creation Date: Sep 16, 2014
 * ---------------------------------------------------------------------------
 */
	import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import util.Menu;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
/**
 * To hold and execute attributes and methods critical to the Book class
 *
 * <hr>
 * Date created: Sep 16, 2014
 * <hr>
 * @author Koi Stephanos
 */
public class Driver
{

	
	/**
	 * To create and interact with Book objects within a Personal Library         
	 *
	 * <hr>
	 * Date created: Sep 16, 2014
	 *
	 * <hr>
	 * @param args
	 */
	public static void main (String [ ] args)
	{
		Menu menu = menu();										//holds the menu for the program
		PersonalLibrary library = new PersonalLibrary();		//holds the library that contains all the book objects
		int choice;												//holds the choice of the user from the menu
		String message = "";											//holds the message output by the program after executing certain tasks
		
		welcomeMessage(); 
		
		while(true)
		{
			choice = menu.getChoice();
			try
			{
				message = proccessChoice (library, choice);
			}
			catch(Exception e)
			{
				message = e.getMessage ( );
			}
			if(message.equals("XXX"))
				break;
			else
				JOptionPane.showMessageDialog (null, message);
		}
		
		goodbyeMessage();
		System.exit (0);
	}
	/**
	 * Uses dialog boxes to collect the book info and creates a book with the given parameters
	 * @Exception Exception, thrown if user enters invalid data
	 *
	 * <hr>
	 * Date created: Sep 16, 2014
	 *
	 * <hr>
	 * @return Book, the created book object
	 */
	public static Book getBookInfo() throws Exception
	{
		int i;													//loop variable
		BookType type;											//holds the booktype
		String author;											//holds an author input by user
		ArrayList<String> authors = new ArrayList<String>();	//holds all authors for a given book
		
		
		//collects the title and cover photo from the user
		String title = JOptionPane.showInputDialog (null, "What is the Title of the Book?", "Book Info", JOptionPane.QUESTION_MESSAGE);
		String coverPhoto = JOptionPane.showInputDialog (null, "What is the Cover Photo of the Book?", "Book Info", JOptionPane.QUESTION_MESSAGE);
		if(title.equals ("") || coverPhoto.equals (""))
			throw new Exception("Error! Must enter a title and cover photo!");
		
		//collects the book type from the user and converts it to an enum
		String strType = JOptionPane.showInputDialog (null, "What is the Genre? Pick from: FICTION, BIOGRAPHY, HISTORY, REFERENCE, OTHER (Case Sensitive)", "Book Info", JOptionPane.QUESTION_MESSAGE);
		type = BookType.valueOf (strType);
		
		
		//collects the price of the book
		String strPrice = JOptionPane.showInputDialog (null, "What is the Price of the book in decimal form?", "Book Info", JOptionPane.QUESTION_MESSAGE);
		double price = Double.parseDouble (strPrice);
		
		//collects the amount of authors from the user, and then prompts the user to input that many authors into the authors array
		String numOfAuthors = JOptionPane.showInputDialog (null, "How Many Authors? (Max 4)", "Book Info", JOptionPane.QUESTION_MESSAGE);
		int numberOfAuthors = Integer.parseInt (numOfAuthors);
		if(numberOfAuthors != 1 && numberOfAuthors != 2 && numberOfAuthors != 3 && numberOfAuthors != 4)
			throw new Exception("Error! Number of authors must be between 1 and 4!");
		for(i = 0; i < numberOfAuthors; i++)
			{
				author = JOptionPane.showInputDialog (null, "What is the Author Name?", "Book Info", JOptionPane.QUESTION_MESSAGE);
				authors.add(author);
			}
		if(authors.isEmpty ( ))
			throw new Exception("Error! Must enter at least one author!");
		
		
		//creates and returns the book with the given info and increases the book count by 1
		Book book = new Book(title, price, authors, coverPhoto, type);
		return book;
		
	}//end of getBookInfo()
	
	/**
	 * Creates and displays a string containing the info for the given book        
	 *
	 * <hr>
	 * Date created: Sep 16, 2014
	 *
	 * <hr>
	 * @param book, the book we want the string of info for
	 */
	public static void displayBook(Book book)
	{
		String bookInfo = book.toString ( );
		
		JOptionPane.showMessageDialog (null, bookInfo);
	}//end of displayBook(Book)
	
	/**
	 * Creates a welcome message for the program using Dialog boxes       
	 *
	 * <hr>
	 * Date created: Sep 16, 2014
	 *
	 * <hr>
	 * @param projectName, projectPurpose, projectAuthor, authorContactInfo, projectNumber
	 */
	public static void welcomeMessage()
	{
		String projectName = "The PersonalLibrary Class";											//holds name of project
		String projectPurpose  = "To Input and Output Libraries from a txt file";							//holds purpose of project
		String projectAuthor = "Koi Stephanos";											//holds author of project
		String authorContactInfo = "stephanos@goldmail.etsu.edu";						//holds the contact info of the author
		int projectNumber = 4;															//holds the number of the project
		
		String message = "";				//holds the message
		
		message += "Project Name: " + projectName + "\nProject Number: " + projectNumber + "\nProject Purpose: " + projectPurpose + 
				   "\nProject Author: " + projectAuthor + "\nAuthor Contact Info: " + authorContactInfo;
		
		//displays the message
		JOptionPane.showMessageDialog (null, message);
	}//end of welcomeMessage
	
	/**
	 * Creates a goodbye message     
	 *
	 * <hr>
	 * Date created: Sep 16, 2014
	 *
	 * <hr>
	 */
	public static void goodbyeMessage()
	{
		String message = "";				//holds the message
		
		message += "Thank you for using The PersonalLibrary program!";
						
		//displays the message
		JOptionPane.showMessageDialog (null, message);				
	}
	
	/**
	 * Provides Menu options for the user         
	 *
	 * <hr>
	 * Date created: Oct 15, 2014
	 *
	 * <hr>
	 * @return Menu, the menu to be used in the program
	 */
	public static Menu menu()
	{
		Menu menu = new Menu("Main Menu");
		
		menu.addChoice ("Add new Book");
		menu.addChoice ("Remove a Book");
		menu.addChoice ("Retrieve a Book");
		menu.addChoice ("Determine amount of Books");
		menu.addChoice ("Determine value of Books");
		menu.addChoice ("Sort Books Alphabetically");
		menu.addChoice ("Display all Books");
		menu.addChoice ("Import Library from file");
		menu.addChoice ("Save library to file");
		menu.addChoice ("End Program");
		
		return menu;
	}
	
	/**
	 * To take the user's input from the menu and conduct the appropriate operations   
	 *     
	 *
	 * <hr>
	 * Date created: Oct 15, 2014
	 *
	 * <hr>
	 * @param library
	 * @param choice, given from menu, entered by user
	 * @return message, displays the success or failure of the given operation
	 * @throws Exception, multiple if bad input is given or if input is out of the bounds of the library
	 */
	public static String proccessChoice(PersonalLibrary library, int choice) throws Exception 
	{
		Book book;
		int currentSize = library.determineSize ( );
		ArrayList<Book> books = new ArrayList<Book>(currentSize);
		String tempChoice;
		int temp;
		String title;
		String author;
		String bookType;
		String message = "";
		DecimalFormat df = new DecimalFormat ("$0.00");
		
		switch(choice)
		{
			//add a new book
			case 1:
				book = getBookInfo();
				library.addBook(book);
				message = "\nBook Added!";
				break;
			
			//remove a book
			case 2:
				title = JOptionPane.showInputDialog (null, "What is the Title of the Book?", "Book Info", JOptionPane.QUESTION_MESSAGE);
				library.removeBook (title);
				message = "\nBook Removed";
				break;
				
			//retrieve a book
			case 3:
				tempChoice = JOptionPane.showInputDialog (null, "Select a 1 to search by Title, 2 to search by Author, and 3 by Book Type, or select 4 to enter a specific book within the library", "Retrieve Book", JOptionPane.QUESTION_MESSAGE);
				temp = Integer.parseInt (tempChoice);
				switch(temp)
				{
					//by title
					case 1:
						title = JOptionPane.showInputDialog (null, "What is the Title of the Book?", "Book Info", JOptionPane.QUESTION_MESSAGE);
						book = library.retrieveBook (title);
						message = "The book with that title is: \n" + book.toString ( );
						break;
						
					//by author
					case 2:
						author = JOptionPane.showInputDialog (null, "What is the Author of the Book?", "Book Info", JOptionPane.QUESTION_MESSAGE);
						books = library.retrieveBooksByAuthor (author);
						message = "The books with matching authors are as follows: \n" + books.toString ( );
						break;
						
					//by type
					case 3:
						bookType = JOptionPane.showInputDialog (null, "What is the Type of the Book? Must be FICTION, BIOGRAPHY, HISTORY, REFERENCE, or OTHER", "Book Info", JOptionPane.QUESTION_MESSAGE);
						books = library.retrieveBooksByType (bookType);
						message = "The books with matching types are as follows: \n" + books.toString ( );
						break;
						
					//by position in library
					case 4:
						tempChoice = JOptionPane.showInputDialog (null, "What is the position of the book within the library?", "Book Info", JOptionPane.QUESTION_MESSAGE);
						temp = Integer.parseInt (tempChoice);
						book = library.retrieveBook (temp-1);
						if(temp > currentSize)
							throw new Exception("Error! Library does not contain that many books!");
						else
							message = "The book in that position is: \n" + book.toString ( );
						break;
				}
				break;
				
			//determine amount of books
			case 4:
				int amount = library.determineSize ( );
				message = "\nThe amount of books currently in the library is " + Integer.toString (amount);
				break;
				
			//determine value of books
			case 5:
				double value = library.libraryValue ( );
				message = "\nThe total value of the library is " + df.format(value);
				break;
				
			//sort books
			case 6:
				library.sortBooks ( );
				message = "\nBooks Sorted";
				break;
				
			//display books
			case 7:
				message = library.toString ( );
				break;
				
			//imports existing library from a txt file
			case 8:
				Boolean save = library.isSaveNeeded ( );
				if(save == true)
				{
					String local = library.getFileLocal ( );
					library.saveFile (local);
				}
				//sets up file chooser
				JFileChooser chooser = new JFileChooser("LibraryData");
				FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
				chooser.setFileFilter (filter);
				chooser.setDialogTitle ("Select the existing file! ");
				chooser.setApproveButtonToolTipText ("Select the file you want to open and click it! ");
				
				//collects chosen file from user
				int button = chooser.showOpenDialog (null);
				
				//Processes choice if made
				try
				{
					if(button == JFileChooser.APPROVE_OPTION)
					{
						File file = chooser.getSelectedFile();
						String inputFile = file.getPath ( );
						library = new PersonalLibrary(inputFile);
						message = "File Imported!";
					}
				}	
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog (null, "Error! No File Seclected!");
				}
				break;
				
			//saves library to a txt file
			case 9:
				//sets up file chooser
				JFileChooser chooser2 = new JFileChooser("LibraryData");
				FileNameExtensionFilter filter2 = new FileNameExtensionFilter("Text Files", "txt");
				chooser2.setFileFilter (filter2);
				chooser2.setDialogTitle ("Select the file you would like to save to! ");
				chooser2.setApproveButtonToolTipText ("Select the file you want to open and click it! ");
				
				//collects chosen file from user
				button = chooser2.showOpenDialog (null);
				
				//Processes choice if made
				try
				{
					if(button == JFileChooser.APPROVE_OPTION)
					{
						File file = chooser2.getSelectedFile();
						String outputFile = file.getPath();
						library.saveFile (outputFile);
						message = "File Saved!";
					}
				}	
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog (null, "Error! No File Seclected!");
				}
				break;
				
			//end program
			case 10:
				save = library.isSaveNeeded ( );
				if(save == true)
				{
					String local = library.getFileLocal ( );
					library.saveFile (local);
				}
				message = "XXX";
				break;
				
		}
		return message;
	}
	
	
}//end of Driver
